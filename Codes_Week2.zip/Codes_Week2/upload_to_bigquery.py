from google.cloud import bigquery
from google.oauth2 import service_account

# Path to the service account key file
service_account_key_file = 'intern-project-415606-df671484ed7a.json'

# Authenticate using service account credentials
credentials = service_account.Credentials.from_service_account_file(
    service_account_key_file)

# Initialize a BigQuery client
client = bigquery.Client(credentials=credentials)

# Specify your Google Cloud Platform project ID
project_id = 'intern-project-415606'

# Specify the dataset ID
dataset_id = 'customer_data'

# Create the dataset if it doesn't exist
dataset_ref = client.dataset(dataset_id)
dataset = bigquery.Dataset(dataset_ref)

try:
    dataset = client.create_dataset(dataset)  # API request
    print(f'Dataset {dataset.dataset_id} created.')
except Exception as e:
    print(f'Dataset {dataset.dataset_id} already exists.')

# Specify the table ID
table_id = 'Walmart_sales_table'

# Path to your CSV file in Google Cloud Storage
source_uri = 'gs://bucket-for-intern-project-415606/Walmart_sales.csv'

# Define the schema of your data (if it's not inferred)
# column = 'Store', 'Date', 'Weekly_Sales', 'Holiday_Flag', 'Temperature', 'Fuel_Price', 'CPI', 'Unemployment'
schema = [
    bigquery.SchemaField('Store', 'INTEGER'),
    bigquery.SchemaField('Date', 'DATE'),
    bigquery.SchemaField('Weekly_Sales', 'FLOAT'),
    bigquery.SchemaField('Holiday_Flag', 'INTEGER'),
    bigquery.SchemaField('Temperature', 'FLOAT'),
    bigquery.SchemaField('Fuel_Price', 'FLOAT'),
    bigquery.SchemaField('CPI', 'FLOAT'),
    bigquery.SchemaField('Unemployment', 'FLOAT'),
]

# Configure the job options
job_config = bigquery.LoadJobConfig(
    schema=schema,
    skip_leading_rows=1,  # if your CSV file has a header
    source_format=bigquery.SourceFormat.CSV,
)

# Start the job to load data from the CSV file into BigQuery
job = client.load_table_from_uri(
    source_uri,
    f'{project_id}.{dataset_id}.{table_id}',
    job_config=job_config,
)

# Wait for the job to complete
job.result()

print(f'Loaded {job.output_rows} rows into {dataset_id}.{table_id}')
